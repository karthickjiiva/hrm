<?php

namespace App\Models;

use App\Casts\Hash;
use App\Classes\Common;
use App\Traits\EntrustUserTrait;
use Carbon\Carbon;
use Illuminate\Notifications\Notifiable;
use PHPOpenSourceSaver\JWTAuth\Contracts\JWTSubject;
use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\Hash as FacadesHash;
use Illuminate\Database\Eloquent\Builder;
use App\Models\EmployeeType;

class User extends BaseModel implements AuthenticatableContract, JWTSubject
{
    use Notifiable, EntrustUserTrait, Authenticatable, HasFactory;

    protected $table = 'users';

    protected $default = [
    'id','xid', 'name', 'employee_number', 'joining_date',
    'probation_end_date', 'probation_start_date', 'profile_image',
    'notice_end_date', 'notice_start_date', 'address', 'end_date', 'dob',
    'profile_image_url', 'location_id','employee_type_id','designation_id', 'department_id',
    'is_manager', 'hra', 'performance_pay', 'allowance','employeeType',
    'uan_number', 'pf_number', 'esi_number', 'pan_number', 'aadhar_number',
    'emergency_contact_name','emergency_contact_number','alternate_phone',
    'has_resigned','resignation_date','resignation_reason','has_rejoined','rejoining_date','rejoining_reason',
    'esi_enabled', 'esi_percentage', 'monthly_esi','monthly_amount', 'annual_esi',
    'pf_enabled', 'pf_percentage', 'monthly_pf', 'annual_pf',
        'prof_tax_enabled', 'prof_tax_percentage', 'monthly_prof_tax', 'annual_prof_tax',
        'tds_enabled', 'tds_percentage', 'monthly_tds', 'annual_tds',
        'hra_percent_monthly', 'monthly_hra_percent_monthly', 'annual_hra_percent_monthly',
        'allowance_percent', 'monthly_allowance_percent', 'annual_allowance_percent',
        'food_allowance_percent', 'monthly_food_allowance_percent', 'annual_food_allowance_percent'
];




    protected $guarded = ['id', 'company_id', 'created_at', 'updated_at'];

    protected $dates = ['last_active_on'];

    protected $hidden = [ 'role_id', 'employee_status_id', 'password', 'remember_token', 'department_id', 'designation_id', 'shift_id', 'location_id', 'salary_group_id'];

    protected $appends = ['xid', 'x_company_id', 'x_employee_status_id', 'x_role_id', 'x_salary_group_id', 'x_report_to', 'profile_image_url', 'x_department_id', 'x_designation_id', 'x_shift_id', 'x_location_id', 'x_employee_type_id' , 'duration'];

    protected $filterable = ['name', 'user_type', 'email', 'status', 'phone', 'shift_id'];

    protected $hashableGetterFunctions = [
        'getXCompanyIdAttribute' => 'company_id',
        'getXRoleIdAttribute' => 'role_id',
        'getXDepartmentIdAttribute' => 'department_id',
        'getXDesignationIdAttribute' => 'designation_id',
        'getXShiftIdAttribute' => 'shift_id',
        'getXLocationIdAttribute' => 'location_id',
        'getXEmployeeTypeIdAttribute' => 'employee_type_id',
        'getXReportToAttribute' => 'report_to',
        'getXSalaryGroupIdAttribute' => 'salary_group_id',
        'getXEmployeeStatusIdAttribute' => 'employee_status_id'
    ];

    protected $casts = [
        'company_id' => Hash::class . ':hash',
        'role_id' => Hash::class . ':hash',
        'employee_status_id' => Hash::class . ':hash',
        'login_enabled' => 'integer',
        'is_superadmin' => 'integer',
        'department_id' => Hash::class . ':hash',
        'designation_id' => Hash::class . ':hash',
        'location_id' => Hash::class . ':hash',
        'employee_type_id' => Hash::class . ':hash',
        'shift_id' => Hash::class . ':hash',
        'is_married' => 'integer',
        'is_manager' => 'integer',
        'report_to' => Hash::class . ':hash',
        'last_active_on' => 'datetime',
        'salary_group_id' => Hash::class . ':hash',
        'probation_start_date' => 'date',
        'probation_end_date' => 'date',
        'notice_start_date' => 'date',
        'notice_end_date' => 'date',
        'basic_salary' => 'double',
        'hra' => 'double',
        'performance_pay' => 'double',
        'allowance' => 'double',
        'aadhar_number' => 'string',
        'uan_number' => 'string',
        'pf_number' => 'string',
        'esi_number' => 'string',
        'pan_number' => 'string',
        'emergency_contact_name' => 'string',
        'emergency_contact_number' => 'string',
        'alternate_phone' => 'string',
        'has_resigned' => 'boolean',
        'resignation_date' => 'date',
        'resignation_reason' => 'string',
        'has_rejoined' => 'boolean',
        'rejoining_date' => 'date',
        'rejoining_reason' => 'string',
        'esi_enabled' => 'boolean',
        'pf_enabled' => 'boolean',
        'prof_tax_enabled' => 'boolean',
        'tds_enabled' => 'boolean',
        'esi_percentage' => 'float',
        'prof_tax_percentage' => 'float',
        'tds_percentage' => 'float',
        'monthly_esi' => 'float',
        'annual_esi' => 'float',
        'pf_percentage'=>'float',
        'monthly_amount' => 'float',
        'monthly_pf' => 'float',
        'annual_pf' => 'float',
        'monthly_prof_tax' => 'float',
        'annual_prof_tax' => 'float',
        'monthly_tds' => 'float',
        'annual_tds' => 'float',
        'hra_percent_monthly' => 'float',
        'monthly_hra_percent_monthly' => 'float',
        'annual_hra_percent_monthly' => 'float',
        'allowance_percent' => 'float',
        'monthly_allowance_percent' => 'float',
        'annual_allowance_percent' => 'float',
        'food_allowance_percent' => 'float',
        'monthly_food_allowance_percent' => 'float',
        'annual_food_allowance_percent' => 'float'

    ];

    protected $permissions = ['salary_settings', 'leaves_view', 'assets_view', 'leave_types_view'];

    protected static function boot()
    {
        parent::boot();

        static::addGlobalScope('type', function (Builder $builder) {
            $builder->where('users.user_type', '=', 'staff_members');
        });
    }

    public function location()
    {
        return $this->belongsTo(Location::class, 'location_id', 'id');
    }

    public function employeeType()
    {
        // return $this->belongsTo(EmployeeType::class, 'employee_type_id', 'id');
        return $this->belongsTo(EmployeeType::class, 'employee_type_id', 'id');
    }

    public function employeeWorkStatus()
    {
        return $this->belongsTo(EmployeeWorkStatus::class, 'employee_status_id', 'id');
    }

    public function setPasswordAttribute($value)
    {
        if ($value) {
            $this->attributes['password'] = FacadesHash::make($value);
        }
    }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }

    public function setUserTypeAttribute($value)
    {
        $this->attributes['user_type'] = 'staff_members';
    }

    public function getProfileImageUrlAttribute()
    {
        $userImagePath = Common::getFolderPath('userImagePath');

        return $this->profile_image == null ? asset('images/user.png') : Common::getFileUrl($userImagePath, $this->profile_image);
    }

    public function getDurationAttribute()
    {
        $joiningDate = $this->joining_date;
        $endDate = $this->end_date;


        if ($joiningDate != null) {
            if ($endDate == null) {
                $endDates = Carbon::parse($endDate);

                // Calculate the difference in years, months, and days
                $years = $endDates->diffInYears($joiningDate);
                $months = $endDates->copy()->subYears($years)->diffInMonths($joiningDate);
                $days = $endDates->copy()->subYears($years)->subMonths($months)->diffInDays($joiningDate);
            } else {
                $now = Carbon::now();

                // Calculate the difference in years, months, and days
                $years = $now->diffInYears($joiningDate);
                $months = $now->copy()->subYears($years)->diffInMonths($joiningDate);
                $days = $now->copy()->subYears($years)->subMonths($months)->diffInDays($joiningDate);
            }

            $durationParts = [];

            if ($years > 0) {
                $durationParts[] = "{$years} y";
            }

            if ($months > 0) {
                $durationParts[] = "{$months} m";
            }

            if ($days > 0) {
                // Always show days if there are no other parts
                $durationParts[] = "{$days} d";
            }

            return implode(' ', $durationParts);
        }

        return "";
    }

    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function designation()
    {
        return $this->belongsTo(Designation::class);
    }

    public function shift()
    {
        return $this->belongsTo(Shift::class);
    }

    public function reporter()
    {
        return $this->hasOne(User::class, 'id', 'report_to');
    }

    public function appreciation()
    {
        return $this->hasMany(Appreciation::class, 'user_id',  'id');
    }

    public function leaves()
    {
        return $this->hasMany(Leave::class,  'user_id',  'id');
    }

    public function leaveType()
    {
        return $this->hasMany(LeaveType::class, 'created_by', 'id');
    }

    public function assets()
    {
        return $this->hasMany(Asset::class,  'user_id',  'id');
    }

    public function assets_type()
    {
        return $this->belongsTo(AssetType::class, 'user_id',  'id');
    }

    public function salaryGroup()
    {
        return $this->hasOne(SalaryGroup::class, 'id', 'salary_group_id');
    }

    public function salaryGroupUsers()
    {
        return $this->hasMany(SalaryGroupUser::class, 'user_id');
    }
    
    public function leaveMaster()
{
    return $this->hasOne(EmployeeLeaveMaster::class, 'employee_id');
}
    public function bankMaster()
{
    return $this->hasOne(BankMaster::class, 'employee_id', 'id');
}


    public function basicSalaryDetails()
    {
        return $this->hasOne(BasicSalaryDetails::class, 'id', 'user_id');
    }
}
